package com.example.amar.localetest;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Button english, telugu, main;
    private Locale locale;
    private String lang;
    private String appLang;
    private boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        english = (Button) findViewById(R.id.btn_english);
        telugu = (Button) findViewById(R.id.btn_telugu);
        main = (Button) findViewById(R.id.main);

        appLang = (String) Cache.getData(CatchValue.APP_LANGUAGE, MainActivity.this);
        locale = getResources().getConfiguration().locale;
        setLanguageButtonEnable(appLang);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FirstActivity.class);
                startActivity(i);
            }
        });

        english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!(locale.getLanguage().equals("en"))) {
                    if (!flag) {
                        flag = true;
                        lang = "E";
                        Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);
                        Cache.putData(CatchValue.APP_LANGUAGE, MainActivity.this, "en", Cache.CACHE_LOCATION_DISK);
                        setLocaleLanguage("en");
                    }
                }


            }
        });

        telugu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!(locale.getLanguage().equals("te"))) {
                    if (!flag) {
                        flag = true;
                        lang = "T";
                        Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);
                        Cache.putData(CatchValue.APP_LANGUAGE, MainActivity.this, "te", Cache.CACHE_LOCATION_DISK);
                        setLocaleLanguage("te");
                    }
                }


            }
        });

    }

    private void setLocaleLanguage(String language) {

        locale = new Locale(language);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = locale;
        res.updateConfiguration(conf, dm);
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

    }

    private void setLanguageButtonEnable(String AppLang) {
        locale = getResources().getConfiguration().locale;

        if (!TextUtils.isEmpty(AppLang)) {

            if (AppLang.equals("en")) {
                lang = "E";
                Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);

            } else if (AppLang.equals("fr")) {
                lang = "F";
                Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);

            } else if (AppLang.equals("es")) {
                lang = "S";
                Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);

            } else {
                lang = "E";
                Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);
            }

        } else {
            lang = "E";
            Cache.putData(CatchValue.LANGUAGE, MainActivity.this, lang, Cache.CACHE_LOCATION_DISK);
        }
    }

}
