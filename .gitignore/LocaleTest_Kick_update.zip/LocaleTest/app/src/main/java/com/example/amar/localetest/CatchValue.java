package com.example.amar.localetest;

/**
 * Created by innData on 29/01/18.
 */

public class CatchValue {

    public static final String APP_LANGUAGE ="app_Lang" ;
    public static final String LANGUAGE = "language";

}
